// Server side
var express = require('express');
var server = express();
var fs = require('fs');

server.use(express.bodyParser());

// we need the fs module for moving the uploaded files
server.post('/file-upload', function(req, res) {
  // get the temporary location of the file
  var tmp_path = req.files.thumbnail.path;
  // set where the file should actually exists - in this case it is in the "images" directory
  var target_path = './public/images/' + req.files.thumbnail.name;
  // move the file from the temporary location to the intended location
  fs.rename(tmp_path, target_path, function(err) {
    if (err) throw err;
    // delete the temporary file, so that the explicitly set temporary upload dir does not get filled with unwanted files
    fs.unlink(tmp_path, function() {
      if (err) throw err;
      res.send('File uploaded to: ' + target_path + ' - ' + req.files.thumbnail.size + ' bytes');
    });
  });
});

// Database
console.log('db')
var Datastore = require('nedb')
  , db = new Datastore({ filename: 'something.db', nodeWebkitAppName: 'nwtest' });

var document = { hello: 'world'
  , n: 5
  , today: new Date()
  , nedbIsAwesome: true
  , notthere: null
  , notToBeSaved: undefined  // Will not be saved
  , fruits: [ 'apple', 'orange', 'pear' ]
  , infos: { name: 'nedb' }
};

db.insert(document, function (err, newDoc) {   // Callback is optional
  console.log(newDoc)
});

db.find({ nedbIsAwesome: true}, function (err, docs) {
  console.log(docs)
});


// Client side
var app = angular.module('max', ['ngRoute']);

app.config(['$locationProvider', '$routeProvider', function ($locationProvider, $routeProvider) {
  'use strict';
  $locationProvider.html5Mode(false);
  $routeProvider
  .when('/', {templateUrl: 'views/index.html'})
  .when('/images', {templateUrl: 'views/images.html'})
  .otherwise({redirectTo: '/'});
}]);

app.controller('MainCtrl', function ($scope) {
  'use strict';
  $scope.$on('$viewContentLoaded', function () {
    console.log('View Changed');
  });
});

app.controller('TargetFolderCtrl', function ($scope) {
  $scope.save = function (targetFolder) {
    console.log(targetFolder);
  }
});

app.controller('ShowImagesCtrl', function ($scope) {
  $scope.files = fs.readdirSync('/Users/nico/Pictures/mi');
  $scope.images = $scope.files.filter(function (image) {
    return /\.(jpg|png)$/i.test(image);
  });
});

app.directive('file', function(){
  return {
    scope: {
      file: '='
    },
    link: function(scope, el, attrs){
      el.bind('change', function(event){
        var files = event.target.files;
        var file = files[0];
        scope.file = file ? file.path : undefined;
        scope.$apply();
      });
    }
  };
});